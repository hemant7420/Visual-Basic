﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class c1r
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Celcius = New System.Windows.Forms.RadioButton()
        Me.Fahrenheit = New System.Windows.Forms.RadioButton()
        Me.Kelvin = New System.Windows.Forms.RadioButton()
        Me.TextBox2 = New System.Windows.Forms.TextBox()
        Me.TextBox3 = New System.Windows.Forms.TextBox()
        Me.E = New System.Windows.Forms.Button()
        Me.C = New System.Windows.Forms.TextBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.SuspendLayout()
        '
        'Celcius
        '
        Me.Celcius.AutoSize = True
        Me.Celcius.BackColor = System.Drawing.Color.Transparent
        Me.Celcius.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.Celcius.Font = New System.Drawing.Font("Times New Roman", 15.75!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Celcius.ForeColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Celcius.Location = New System.Drawing.Point(68, 94)
        Me.Celcius.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.Celcius.Name = "Celcius"
        Me.Celcius.Size = New System.Drawing.Size(91, 28)
        Me.Celcius.TabIndex = 0
        Me.Celcius.TabStop = True
        Me.Celcius.Text = "Celsius"
        Me.Celcius.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
        Me.Celcius.UseVisualStyleBackColor = False
        '
        'Fahrenheit
        '
        Me.Fahrenheit.AutoSize = True
        Me.Fahrenheit.BackColor = System.Drawing.Color.Transparent
        Me.Fahrenheit.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.Fahrenheit.Font = New System.Drawing.Font("Times New Roman", 15.75!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Fahrenheit.ForeColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Fahrenheit.Location = New System.Drawing.Point(68, 153)
        Me.Fahrenheit.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.Fahrenheit.Name = "Fahrenheit"
        Me.Fahrenheit.Size = New System.Drawing.Size(126, 28)
        Me.Fahrenheit.TabIndex = 1
        Me.Fahrenheit.TabStop = True
        Me.Fahrenheit.Text = "Fahrenheit"
        Me.Fahrenheit.UseVisualStyleBackColor = False
        '
        'Kelvin
        '
        Me.Kelvin.AutoSize = True
        Me.Kelvin.BackColor = System.Drawing.Color.Transparent
        Me.Kelvin.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.Kelvin.Font = New System.Drawing.Font("Times New Roman", 15.75!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Kelvin.ForeColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Kelvin.Location = New System.Drawing.Point(68, 204)
        Me.Kelvin.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.Kelvin.Name = "Kelvin"
        Me.Kelvin.Size = New System.Drawing.Size(84, 28)
        Me.Kelvin.TabIndex = 2
        Me.Kelvin.TabStop = True
        Me.Kelvin.Text = "Kelvin"
        Me.Kelvin.UseVisualStyleBackColor = False
        '
        'TextBox2
        '
        Me.TextBox2.Font = New System.Drawing.Font("Times New Roman", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox2.Location = New System.Drawing.Point(267, 146)
        Me.TextBox2.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.TextBox2.Multiline = True
        Me.TextBox2.Name = "TextBox2"
        Me.TextBox2.Size = New System.Drawing.Size(146, 35)
        Me.TextBox2.TabIndex = 4
        '
        'TextBox3
        '
        Me.TextBox3.Font = New System.Drawing.Font("Times New Roman", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox3.Location = New System.Drawing.Point(267, 204)
        Me.TextBox3.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.TextBox3.Multiline = True
        Me.TextBox3.Name = "TextBox3"
        Me.TextBox3.Size = New System.Drawing.Size(146, 35)
        Me.TextBox3.TabIndex = 5
        '
        'E
        '
        Me.E.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Me.E.Font = New System.Drawing.Font("Times New Roman", 15.75!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.E.Location = New System.Drawing.Point(144, 294)
        Me.E.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.E.Name = "E"
        Me.E.Size = New System.Drawing.Size(169, 56)
        Me.E.TabIndex = 6
        Me.E.Text = "Exit"
        Me.E.UseVisualStyleBackColor = True
        '
        'C
        '
        Me.C.Font = New System.Drawing.Font("Times New Roman", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.C.Location = New System.Drawing.Point(267, 87)
        Me.C.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.C.Multiline = True
        Me.C.Name = "C"
        Me.C.Size = New System.Drawing.Size(146, 35)
        Me.C.TabIndex = 7
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.BackColor = System.Drawing.Color.Transparent
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(263, 41)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(169, 24)
        Me.Label1.TabIndex = 8
        Me.Label1.Text = "Enter Temperature"
        '
        'c1r
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(7.0!, 15.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackgroundImage = Global.WindowsApplication1.My.Resources.Resources.wallpaper_winter_small11
        Me.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.CancelButton = Me.E
        Me.ClientSize = New System.Drawing.Size(465, 415)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.C)
        Me.Controls.Add(Me.E)
        Me.Controls.Add(Me.TextBox3)
        Me.Controls.Add(Me.TextBox2)
        Me.Controls.Add(Me.Kelvin)
        Me.Controls.Add(Me.Fahrenheit)
        Me.Controls.Add(Me.Celcius)
        Me.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ForeColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.Name = "c1r"
        Me.Text = "TEMPERATURE"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents Celcius As System.Windows.Forms.RadioButton
    Friend WithEvents Fahrenheit As System.Windows.Forms.RadioButton
    Friend WithEvents Kelvin As System.Windows.Forms.RadioButton
    Friend WithEvents TextBox2 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox3 As System.Windows.Forms.TextBox
    Friend WithEvents E As System.Windows.Forms.Button
    Friend WithEvents C As System.Windows.Forms.TextBox
    Friend WithEvents Label1 As System.Windows.Forms.Label
End Class
