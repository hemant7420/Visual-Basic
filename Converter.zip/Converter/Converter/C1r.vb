﻿Public Class c1r

    Private Sub TextBox2_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TextBox2.TextChanged
        If (Fahrenheit.Checked = True) Then
            If (IsNumeric(Me.TextBox2.Text) = True) Then
                Me.C.Text = (Me.TextBox2.Text - 32) * (5 / 9)
                Me.TextBox3.Text = Me.C.Text + 273.15
            Else
                C.Clear()
                TextBox2.Clear()
                TextBox3.Clear()
                MessageBox.Show("Wrong input", "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Error)
            End If
        End If
    End Sub

    Private Sub TextBox3_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TextBox3.TextChanged
        If (Kelvin.Checked = True) Then
            If (IsNumeric(Me.TextBox3.Text) = True) Then
                Me.C.Text = Me.TextBox3.Text - 273.15
                Me.TextBox2.Text = Me.C.Text * (9 / 5) + 32
            Else
                C.Clear()
                TextBox2.Clear()
                TextBox3.Clear()
            End If
        End If
    End Sub


    Private Sub Kelvin_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Kelvin.CheckedChanged
        C.Clear()
        TextBox3.Clear()
        TextBox2.Clear()
    End Sub

    Private Sub Fahrenheit_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Fahrenheit.CheckedChanged
        C.Clear()
        TextBox3.Clear()
        TextBox2.Clear()
    End Sub


    Private Sub E_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles E.Click
        Application.Exit()
    End Sub

    Private Sub C_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles C.TextChanged
        If (Celcius.Checked = True) Then
            If (IsNumeric(Me.C.Text) = True) Then
                Me.TextBox3.Text = Me.C.Text - 273.15
                Me.TextBox2.Text = Me.C.Text * (9 / 5) + 32
            Else
                C.Clear()
                TextBox2.Clear()
                TextBox3.Clear()
            End If
            End If
    End Sub
End Class
