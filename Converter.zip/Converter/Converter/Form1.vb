﻿Public Class Login

    Private Sub A_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles A.Click
        If (T1.Text = "admin" Or T1.Text = "Admin") Then
            If (T2.Text = "12345") Then
                Me.Hide()
                c1r.Show()
            Else
                MsgBox("Invalid username or password")
                T1.Clear()
                T2.Clear()
            End If
        Else
            MsgBox("Invalid username or password")
            T1.Clear()
            T2.Clear()
        End If
        
    End Sub

    Private Sub R_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles R.Click
        T1.Clear()
        T2.Clear()
    End Sub

    Private Sub C_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles C.Click
        Application.Exit()
    End Sub
End Class